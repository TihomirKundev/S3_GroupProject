﻿namespace StudentHouse
{
    public class MethodExecutionArgs
    {
    }
}