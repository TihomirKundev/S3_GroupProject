﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace StudentHouse
{
   
    class Student
    {
        private List<int> id = new List<int>();
        private List<String> username = new List<string>();
        private List<String> password = new List<string>();

        private List<String> getUserNames()
        {
        List<String> usernameCopy = new List<string>();
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-TAVNN38\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("Select Username from UsersData", con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                usernameCopy.Add(dr.GetValue(0).ToString());
            }
            con.Close();
            return usernameCopy;

        }
        private List<String> getPasswords()
        {
            List<String> passwordCopy = new List<string>();
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-TAVNN38\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("Select Password from UsersData", con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                passwordCopy.Add(dr.GetValue(0).ToString());
            }
            con.Close();
            return passwordCopy;

        }

     






        public bool checkLogIn(string username, string password)
        {
          
            this.username = getUserNames();
            this.password = getPasswords();
            bool check = false;
            for (int i = 0; i < this.username.Count; i++)
            {
                if (this.username[i] == username && this.password[i] == password)
                {
                    check = true;
                    break;
                }
            }
            return check;

        }

        public void changeName(int ID, string newData)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-TAVNN38\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("Update UsersData set Username=@Username where ID=@ID", con);
            cmd.Parameters.AddWithValue("@Username", newData);
            cmd.Parameters.AddWithValue("@ID", ID);

            cmd.ExecuteNonQuery();
            con.Close();
       
        }
        public void changePassword(int ID, string newData)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-TAVNN38\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("Update UsersData set Password=@Password where ID=@ID", con);
            cmd.Parameters.AddWithValue("@Password", newData);
            cmd.Parameters.AddWithValue("@ID", ID);

            cmd.ExecuteNonQuery();
            con.Close();
        }
        public void changeApartment(int ID, string newData)
        {
            adminForm a = new adminForm();
            
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-TAVNN38\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("Update UsersData set Apartment=@Apartment where ID=@ID", con);
            cmd.Parameters.AddWithValue("@Apartment", newData);
            cmd.Parameters.AddWithValue("@ID", ID);

            cmd.ExecuteNonQuery();
            con.Close();
        }


    }
  

}
