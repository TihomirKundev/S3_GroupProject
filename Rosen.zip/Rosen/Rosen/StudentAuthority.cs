﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
namespace Project
{
    class StudentAuthority
    {
        private UploadStudentData studentAuthority = new UploadStudentData();
        private const string UPPER_CAES = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        private const string NUMBERS = "123456789";
        private const string SPECIALS = @"!@£$%^&*()#€";
        public DataTable GetUsers()
        {
            return studentAuthority.AllUsers();
        }
        public void ModifyUsersData(string option, int userID, string userEmail, string userPassword, int userApartment)
        {
            studentAuthority.ModifyUsersData(option, userID, userEmail, userPassword, userApartment);
        }
        public string GeneratePassword(int passwordSize)
        {
            char[] _password = new char[passwordSize];
            string charSet = "";
            System.Random _random = new Random();
            int counter;

            if (true) charSet += UPPER_CAES.ToLower();

            if (true) charSet += UPPER_CAES;

            if (true) charSet += NUMBERS;

            if (true) charSet += SPECIALS;

            for (counter = 0; counter < passwordSize; counter++)
            {
                _password[counter] = charSet[_random.Next(charSet.Length - 1)];
            }
            return String.Join(null, _password);
        }
    }
}
