﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace Project
{
    class AdminApartment
    {
        private UploadApartmentData uploadAgreementData = new UploadApartmentData();
        private CheckData checkData = new CheckData();

        public DataTable GetApartments()
        {
            return uploadAgreementData.ApartmentsData();
        }
        public void ModifyApartmentData(string option, int apartmentID, string address, string price, string propertyType,
            string interior, int bedrooms, int roomsInApartment)
        {
            uploadAgreementData.ModifyApartmentData(option, apartmentID, address, price, propertyType, interior, bedrooms, roomsInApartment);
        }
        public List<String> apartmentDataInfo(int apartmentID)
        {
            return uploadAgreementData.apartmentDataInfo(apartmentID);
        }
        public void removeAllStudentsWithApartmentID(int apID)
        {
            uploadAgreementData.removeAllStudentsWithApartmentID(apID);
        }
        public void updateApartmentData(int ID, string address, string price, string propertyType, string interior, string bedRooms, string RoomsInApartment)
        {
            uploadAgreementData.updateApartmentData(ID, address, price, propertyType, interior, bedRooms, RoomsInApartment);
        }
        public List<int> addApartmentIDstoComboBox()
        {
            return checkData.addApartmentIDstoComboBox();
        }


    }
}
