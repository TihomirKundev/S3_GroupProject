﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace Project
{
    class UploadStudentData
    {
        private readonly string dataLink = "Server=mssql.fhict.local;Database=dbi484379;User Id=dbi484379;Password=1234;";

        public DataTable AllUsers()
        {
            SqlConnection con = new SqlConnection(@dataLink);
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT * from UsersData", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            con.Close();
            return dt;
        }
        public void ModifyUsersData(string option, int userID, string userEmail, string userPassword, int userApartment)
        {
            SqlConnection con = new SqlConnection(@dataLink);
            con.Open();
            SqlCommand cmd = new SqlCommand("");
            if (option == "Insert")
            {
                cmd = new SqlCommand("insert into UsersData values (@Username,@Password, @Apartment)", con);
                cmd.Parameters.AddWithValue("@Username", userEmail);
                cmd.Parameters.AddWithValue("@Password", userPassword);
                cmd.Parameters.AddWithValue("@Apartment", userApartment);
            }else if(option == "Update")
            {
                cmd = new SqlCommand("Update UsersData set Username =@Username,Password=@Password,Apartment=@Apartment where ID='" + @userID + "'", con);
                cmd.Parameters.AddWithValue("@Username", userEmail);
                cmd.Parameters.AddWithValue("@Password", userPassword);
                cmd.Parameters.AddWithValue("@Apartment", userApartment);
                cmd.Parameters.AddWithValue("@ID", userID);
            }
            else
            {
                cmd = new SqlCommand("DELETE FROM UsersData WHERE ID = '"+userID+"'", con);
                cmd.Parameters.AddWithValue("@ID", userID);
            }
            cmd.ExecuteNonQuery();
            con.Close();
        }

    }
}
