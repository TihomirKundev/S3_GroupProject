﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
namespace Project
{
    class UploadAgreementData
    {
        private readonly string dataLink = "Server=mssql.fhict.local;Database=dbi484379;User Id=dbi484379;Password=1234;";

        public DataTable uploadAgreements(int changeData)
        {
            SqlConnection con = new SqlConnection(@dataLink);
            con.Open();
            SqlCommand cmd;
            if (changeData == 0)
            cmd = new SqlCommand("SELECT  s.CreatedUserID,u.Username as ForUser, Agreement, Process,StartDate,EndDate FROM StudentAgreements s inner join UsersData u ON  s.AgreementForUserID = u.ID", con);
            else
            cmd = new SqlCommand("SELECT  s.AgreementForUserID,s.ID,u.Username as FromUser, Agreement, Process,StartDate,EndDate FROM StudentAgreements s inner join UsersData u ON  s.CreatedUserID = u.ID", con);            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            con.Close();
            return dt;
        }
        public void approveAgreement(int ID,string approvedNotApproved)
        {
            SqlConnection con = new SqlConnection(@dataLink);
            con.Open();
            SqlCommand cmd = new SqlCommand("Update StudentAgreements set Process=@Process where ID=@ID", con);
            cmd.Parameters.AddWithValue("@ID", ID);
            cmd.Parameters.AddWithValue("@Process", approvedNotApproved);
            cmd.ExecuteNonQuery();
            con.Close();
        }
        public DataTable usersInTheSameApartment()
        {
            SqlConnection con = new SqlConnection(@dataLink);
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT Username,ID FROM UsersData WHERE Apartment = '" + User.apartmentID + "' AND ID != '" + User.userID+ "'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            con.Close();
            return dt;
        }
        public void createAgreement(int agreementForUserID, string agreement, string startDate, string endDate)
        {
            SqlConnection con = new SqlConnection(@dataLink);
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into StudentAgreements values (@CreatedUserID,@ApartmentID, @AgreementForUserID," +
                "@Agreement,@Process, @StartDate,  @EndDate)", con);
            cmd.Parameters.AddWithValue("@CreatedUserID", User.userID);
            cmd.Parameters.AddWithValue("@ApartmentID", User.apartmentID);
            cmd.Parameters.AddWithValue("@AgreementForUserID", agreementForUserID);
            cmd.Parameters.AddWithValue("@Agreement", agreement);
            cmd.Parameters.AddWithValue("@Process", "Waiting for respond");
            cmd.Parameters.AddWithValue("@StartDate", startDate);
            cmd.Parameters.AddWithValue("@EndDate", endDate);
            cmd.ExecuteNonQuery();
            con.Close();
        }

    }
}
