﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
namespace Project
{
    class StudentAgreement
    {
        UploadAgreementData agreements = new UploadAgreementData();
        
        public DataTable checkAgreements(int choice)
        {
            DataTable allAgreements = agreements.uploadAgreements(choice);
            for (int i = 0; i < allAgreements.Rows.Count; i++)
                allAgreements.Rows[i][choice+1] = allAgreements.Rows[i][choice+1].ToString().Substring(0, allAgreements.Rows[i][choice+1].ToString().IndexOf("@"));
            DataTable agreementsUserHasCreated = allAgreements.Clone();
            DataRow[] orderRows = new DataRow[0];
            if(choice == 0)
                orderRows = allAgreements.Select("CreatedUserID= '" + User.userID + "'");
            else
                orderRows = allAgreements.Select("AgreementForUserID= '" + User.userID + "'");

            foreach (DataRow dr in orderRows)
            {
                agreementsUserHasCreated.ImportRow(dr);
            }
            agreementsUserHasCreated.Columns.RemoveAt(0);
            return agreementsUserHasCreated;
        }
        public void approveAgreement(int ID,string approvedNotApproved)
        {
            agreements.approveAgreement(ID, approvedNotApproved);
        }
        public DataTable usersInTheSameApartment()
        {
            return agreements.usersInTheSameApartment();
        }
        public void createAgreement(int agreementForUserID, string agreement, string startDate, string endDate)
        {
            agreements.createAgreement(agreementForUserID, agreement, startDate, endDate);
        }
    }
}
