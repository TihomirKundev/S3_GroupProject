﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
namespace Project
{
    class UploadApartmentData
    {
        private readonly string dataLink = "Server=mssql.fhict.local;Database=dbi484379;User Id=dbi484379;Password=1234;";
        public DataTable uploadUserApartment()
        {
            SqlConnection con = new SqlConnection(@dataLink);
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT Address, Price, PropertyType,Interior FROM ApartmentsData WHERE ID = '" + User.apartmentID+ "'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            con.Close();
            return dt;
        }

        public DataTable ApartmentsData()
        {
            SqlConnection con = new SqlConnection(@dataLink);
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT * from ApartmentsData", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            con.Close();
            return dt;
        }
        public void ModifyApartmentData(string option, int apartmentID, string address, string price, string propertyType,
            string interior, int bedrooms, int roomsInApartment)
        {
            SqlConnection con = new SqlConnection(@dataLink);
            con.Open();
            SqlCommand cmd = new SqlCommand("");
            if (option == "Insert")
            {
                cmd = new SqlCommand("insert into ApartmentsData values (@Address, @Price, @PropertyType,@Interior,@Bedrooms,@RoomsInApartment)", con);
                cmd.Parameters.AddWithValue("@Address", address);
                cmd.Parameters.AddWithValue("@Price", price);
                cmd.Parameters.AddWithValue("@PropertyType", propertyType);
                cmd.Parameters.AddWithValue("@Interior", interior);
                cmd.Parameters.AddWithValue("@Bedrooms", bedrooms);
                cmd.Parameters.AddWithValue("@RoomsInApartment", roomsInApartment);

            }
            else if (option == "Update")
            {
                cmd = new SqlCommand("Update ApartmentsData set ID=@ID,Address=@Address,Price=@Price, PropertyType=@PropertyType," +
                    "Interior=@Interior,@Bedrooms=Bedrooms, RoomsInApartment=@RoomsInApartment where ID='" + apartmentID + "'", con);
                cmd.Parameters.AddWithValue("@Address", address);
                cmd.Parameters.AddWithValue("@Price", price);
                cmd.Parameters.AddWithValue("@PropertyType", propertyType);
                cmd.Parameters.AddWithValue("@Interior", interior);
                cmd.Parameters.AddWithValue("@Bedrooms", bedrooms);
                cmd.Parameters.AddWithValue("@RoomsInApartment", roomsInApartment);
                cmd.Parameters.AddWithValue("@ID", apartmentID);
            }
            else
            {
                cmd = new SqlCommand("DELETE FROM ApartmentsData WHERE ID = '" + apartmentID + "'", con);
                cmd.Parameters.AddWithValue("@ID", apartmentID);
            }
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public List<String> apartmentDataInfo(int id)
        {
            List<string> str = new List<string>();
            SqlConnection con = new SqlConnection(@dataLink);
            con.Open();
            //SqlCommand cmd = new SqlCommand("Select * from Apartments a inner join Users u ON a.ID=u.ID WHERE a.ID='"+1+"'", con);
            SqlCommand cmd = new SqlCommand("Select * from ApartmentsData a WHERE a.ID='" + id + "'", con);

            SqlDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                str.Add(dr.GetValue(0).ToString());
                str.Add(dr.GetValue(1).ToString());
                str.Add(dr.GetValue(2).ToString());
                str.Add(dr.GetValue(3).ToString());
                str.Add(dr.GetValue(4).ToString());
                str.Add(dr.GetValue(5).ToString());
                str.Add(dr.GetValue(6).ToString());


            }
            con.Close();
            return str;
        }

        public void removeAllStudentsWithApartmentID(int apID)
        {
            SqlConnection con = new SqlConnection(@dataLink);
            con.Open();
            SqlCommand cmd = new SqlCommand("Update UsersData set Apartment=0 where Apartment=@Apartment", con);
            cmd.Parameters.AddWithValue("@Apartment", apID);
            cmd.ExecuteNonQuery();
            con.Close();
        }
        public void updateApartmentData(int ID, string address, string price, string propertyType, string interior, string bedRooms, string RoomsInApartment)
        {
            SqlConnection con = new SqlConnection(@dataLink);
            con.Open();
            SqlCommand cmd = new SqlCommand("Update ApartmentsData set Address=@Address,Price=@Price," +
                "PropertyType=@PropertyType,Interior=@Interior, Bedrooms=@Bedrooms," +
                "RoomsInApartment=@RoomsInApartment where ID=@ID", con);
            cmd.Parameters.AddWithValue("@ID", ID);
            cmd.Parameters.AddWithValue("@Address", address);
            cmd.Parameters.AddWithValue("@Price", price);
            cmd.Parameters.AddWithValue("@PropertyType", propertyType);
            cmd.Parameters.AddWithValue("@Interior", interior);
            cmd.Parameters.AddWithValue("@Bedrooms", bedRooms);
            cmd.Parameters.AddWithValue("@RoomsInApartment", RoomsInApartment);
            cmd.ExecuteNonQuery();
            con.Close();
        }
    }
}
