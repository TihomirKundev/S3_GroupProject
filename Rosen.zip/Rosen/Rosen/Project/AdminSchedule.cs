﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rosen
{
    class AdminSchedule
    {
        //CreateScheduleData method
        //UpdateScheduleData method
        //DeleteScheduleData method
    }
}
