﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rosen
{
    class StudentAuthority
    {
        //ChangeName method
        //ChangePassword method
        //ChangeApartment method
        //GeneratePassword method
        //CreateUserData method
        //DeleteUserData method
    }
}
