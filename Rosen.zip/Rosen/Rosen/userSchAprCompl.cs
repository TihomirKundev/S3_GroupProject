﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
namespace Project
{
    class userSchAprCompl
    {
        public void sendComplaint(string complaintMessage)
        {
            UploadComplaintData complaint = new UploadComplaintData();
            complaint.sendComplaint(complaintMessage);
        }
        public DataTable userApartment()
        {
            UploadApartmentData apartmentData = new UploadApartmentData();
            return apartmentData.uploadUserApartment();
        }
        public DataTable scheduleForUser()
        {
            UploadScheduleData schedule = new UploadScheduleData();
            return schedule.uploadScheduleUsers();
        }
        public List<String> scheduleObligations()
        {
            UploadScheduleData schedule = new UploadScheduleData();
            return schedule.scheduleObligations();
            
        }
    }
}
