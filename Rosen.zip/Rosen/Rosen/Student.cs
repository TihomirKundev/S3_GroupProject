﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
namespace Project
{
    class Student
    {
        private userSchAprCompl userSchAprCompl = new userSchAprCompl();
        public DataTable apartmentData()
        {
            return userSchAprCompl.userApartment();
        }
        public DataTable scheduleForUser()
        {
            return userSchAprCompl.scheduleForUser();
        }
        public List<String> scheduleDuty()
        {
            return userSchAprCompl.scheduleObligations();
        }

        private DataTable agreementUserCreatedData;
        private DataTable agreementForUserData;

        public void sendComplaint(string message)
        {
            userSchAprCompl complaint = new userSchAprCompl();
            complaint.sendComplaint(message);
        }


        //GetID method
        //GetAppartment method
    }
}
