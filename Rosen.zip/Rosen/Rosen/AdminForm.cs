﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class AdminForm : Form
    {
        private StudentAuthority studentAuthority = new StudentAuthority();
        private AdminApartment adminApartments = new AdminApartment();
        private DataTable usersDataTable, apartmentsDataTable, usersAndApartmentsDataTable, complaintMessagesDataTable,
            scheduleForApartmentsDataTable, studentAgreementsDataTable;
        public AdminForm()
        {
            InitializeComponent();
            usersDataTable = studentAuthority.GetUsers();
            apartmentsDataTable = adminApartments.GetApartments();
            dataGridView1.DataSource = usersDataTable;
        }
        private void ShowCreateUser(bool change)
        {
            firstName.Visible = change;
            secondName.Visible = change;
            fnLabel.Visible = change;
            snLabel.Visible = change;
            createUserBtn.Visible = change;
            userAddApartment.Visible = change;
            apLabel.Visible = change;
        }
        private void ShowUpdateUser(bool change)
        {
            oldOne.Visible = change;
            newOne.Visible = change;
            oldData.Visible = change;
            newData.Visible = change;
            updateUserBtn.Visible = change;
        }
        private void ShowUpdateFilters(bool change)
        {
            UptadeUserInfoBy.Visible = change;
            ChangeUpdateLabel.Visible = change;
        }
        private void TurnOffApartmentBtns(bool change)
        {
            //createApartmentBtn.Visible = change;
            //updateApartmentBtn.Visible = change;
        }
        private void TurnOffScheduleBtns(bool change)
        {
            //addScheduleBtn.Visible = change;
            //updateSchedule.Visible = change;
        }
        private void visibleFalse()
        {
            ShowCreateUser(false);
            ShowUpdateUser(false);
            ShowUpdateFilters(false);
            TurnOffApartmentBtns(false);
            TurnOffScheduleBtns(false);
        }
        #region Users
        private void updateUserDataBtn_Click(object sender, EventArgs e)
        {
            availableApartments.DataSource = null;
            availableApartments.DataSource = adminApartments.addApartmentIDstoComboBox();
            comboBoxApartIds();
            if (oldData.Visible == false)
                visibleFalse();
            if (dataGridView1.Rows.Count > 0)
            {
                ShowUpdateUser(true);
                ShowUpdateFilters(true);
            }
            else
                MessageBox.Show("There is no data");
        }

        private void createUserBtn_Click(object sender, EventArgs e)
        {
            int check = 0;
            Random rnd = new Random();
            if (String.IsNullOrEmpty(userAddApartment.Text) == false)
            {
                if (!String.IsNullOrEmpty(firstName.Text) || !String.IsNullOrEmpty(secondName.Text))
                {
                    if (!int.TryParse(firstName.Text.Substring(0, 1), out check))
                    {
                        string email = firstName.Text.Substring(0, 1) + "." + secondName.Text + "@studentHousing.mail";
                        string password = studentAuthority.GeneratePassword(rnd.Next(7, 12));
                        studentAuthority.ModifyUsersData("Insert", 0, email, password, Convert.ToInt32(userAddApartment.Text));
                        usersDataTable = studentAuthority.GetUsers();
                        dataGridView1.DataSource = usersDataTable;
                        MessageBox.Show($"You successfully created user with email: {email}");
                        comboBoxApartIds();
                    }
                    else
                        MessageBox.Show("First name cant start with numbers and the max characters for first or last name is 20!");
                }
                else
                    MessageBox.Show("Please fill all fields correctly");
            }
            else
                MessageBox.Show("No available apartments!!");
        }

        private void deleteUserDataBtn_Click(object sender, EventArgs e)
        {
            availableApartments.Visible = false;

            if (dataGridView1.Rows.Count > 0)
            {
                studentAuthority.ModifyUsersData("Delete", Convert.ToInt32(dataGridView1.Rows[getIndex()].Cells[0].Value), "", "", 0);
                DataRow row = (dataGridView1.Rows[getIndex()].DataBoundItem as DataRowView).Row;
                usersDataTable.Rows.Remove(row);
                dataGridView1.DataSource = usersDataTable;
                comboBoxApartIds();
                MessageBox.Show("Successfully deleted");
            }
            else
                MessageBox.Show("There is no data");
        }

        private void createUserDataBtn_Click(object sender, EventArgs e)
        {
            availableApartments.Visible = false;
            if (firstName.Visible == false)
                visibleFalse();
            ShowCreateUser(true);
            comboBoxApartIds();


        }

        private void adminSettings_Tick(object sender, EventArgs e)
        {
            if (updateUserBtn.Visible == true)
            {
                if (changeUserName.Checked == true)
                {
                    oldData.Text = dataGridView1.Rows[getIndex()].Cells[1].Value.ToString();
                    oldOne.Text = "Old email";
                    newOne.Text = "New email";
                }
                if (changeUserPassword.Checked == true)
                {
                    oldData.Text = dataGridView1.Rows[getIndex()].Cells[2].Value.ToString();
                    oldOne.Text = "Old password";
                    newOne.Text = "New password";
                }
                if (changeUserApartment.Checked == true)
                {

                    newData.Visible = false;
                    availableApartments.Visible = true;
                    oldData.Text = dataGridView1.Rows[getIndex()].Cells[3].Value.ToString();
                    oldOne.Text = "Old apartment";
                    newOne.Text = "New apartment";
                }
                else
                {
                    newData.Visible = true;
                    availableApartments.Visible = false;
                }


            }
        }

        private void updateUserBtn_Click(object sender, EventArgs e)
        {
            int check = 0;
            int id = Convert.ToInt32(dataGridView1.Rows[getIndex()].Cells[0].Value);
            string email = Convert.ToString(dataGridView1.Rows[getIndex()].Cells[1].Value);
            string password = Convert.ToString(dataGridView1.Rows[getIndex()].Cells[2].Value);
            int apartment=0;
            if (dataGridView1.Rows[getIndex()].Cells[2].Value != null)
            apartment = Convert.ToInt32(dataGridView1.Rows[getIndex()].Cells[3].Value);
            if (availableApartments.Visible == false)
            {
                if (!String.IsNullOrEmpty(newData.Text))
                {
                    string checkName = newData.Text.Substring(0, 1);
                    if (newData.Text.Length < 50)
                    {
                        if (changeUserName.Checked == true)
                        {

                            usersDataTable.Rows[getIndex()][1] = newData.Text;
                            dataGridView1.DataSource = usersDataTable;
                            studentAuthority.ModifyUsersData("Update", id, newData.Text, password, apartment);
                            MessageBox.Show("Successfully updated");
                        }
                        else

                        if (changeUserPassword.Checked == true)
                        {
                            usersDataTable.Rows[getIndex()][2] = newData.Text;
                            dataGridView1.DataSource = usersDataTable;
                            studentAuthority.ModifyUsersData("Update", id, email, newData.Text, apartment);
                            MessageBox.Show("Successfully updated");
                        }

                    }
                    else
                        MessageBox.Show("New email or password has to be less than 50 characters!");
                }
                else
                    MessageBox.Show("Please fill the field for new data correctly", "Error");
            }
            if (changeUserApartment.Checked == true)
            {
                if (availableApartments.Items.Count.ToString() != "0")
                {
                    usersDataTable.Rows[getIndex()][3] = Convert.ToInt32(availableApartments.Text);
                    dataGridView1.DataSource = usersDataTable;
                    studentAuthority.ModifyUsersData("Update", id, email, email, Convert.ToInt32(availableApartments.Text));
                    MessageBox.Show("Successfully updated");
                    availableApartments.DataSource = null;
                    availableApartments.DataSource = adminApartments.addApartmentIDstoComboBox();
                }
                else
                    MessageBox.Show("There is no available apartments!", "Error");
            }


        }

       

        private void comboBoxApartIds()
        {
            userAddApartment.DataSource = null;
            userAddApartment.DataSource = adminApartments.addApartmentIDstoComboBox();
        }
        #endregion

        #region Apartments
        private void createApartmentBtn_Click(object sender, EventArgs e)
        {
            if (!String.IsNullOrEmpty(addressAp.Text) && priceNumeric.Value != 0 &&
                 !String.IsNullOrEmpty(propertyTypeComboBox.Text) && !String.IsNullOrEmpty(interiorComboBox.Text) &&
                 !String.IsNullOrEmpty(bedroomsComboBox.Text) && !String.IsNullOrEmpty(roomsQuantity.Text))
            {
                string address = addressAp.Text;
                string price = Convert.ToString(priceNumeric.Value);
                string propertyType = propertyTypeComboBox.Text;
                string interior = interiorComboBox.Text;
                string bedrooms = bedroomsComboBox.Text;
                int roomsInApartment = Convert.ToInt32(roomsQuantity.Value);
                comboBoxApartIds();
                adminApartments.ModifyApartmentData("Insert", 0, address, price, propertyType, interior, Convert.ToInt32(bedrooms), roomsInApartment);
                apartmentsDataTable = adminApartments.GetApartments();
                dataGridView1.DataSource = apartmentsDataTable;
                MessageBox.Show("Succesfully added");
            }
            else
            {
                MessageBox.Show("Please fill all fields", "Error some field are empty");
            }
        }

        private void deleteApBtn_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count > 0)
            {
                int apartmentID = Convert.ToInt32(dataGridView1.Rows[getIndex()].Cells[0].Value);
                adminApartments.ModifyApartmentData("Delete", apartmentID, "", "", "", "", 0, 0);
                DataRow row = (dataGridView1.Rows[getIndex()].DataBoundItem as DataRowView).Row;
                apartmentsDataTable.Rows.Remove(row);
                dataGridView1.DataSource = apartmentsDataTable;
                comboBoxApartIds();
                MessageBox.Show($"You deleted apartment with id: {apartmentID}");
            }
            else
                MessageBox.Show("There is no data");
        }

        private void createApBtn_Click(object sender, EventArgs e)
        {
            idTxtBox.Text = "";
            if (createApartmentBtn.Visible == false)
                visibleFalse();
            createApartmentBtn.Visible = true;
            updateApartmentBtn.Visible = false;

        }
        private void areYouSure()
        {
            DialogResult dialogResult = MessageBox.Show("Students with this apartment would have null as apartment", "Are you sure?", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {

                int getID = Convert.ToInt32(dataGridView1.Rows[getIndex()].Cells[0].Value);
                adminApartments.removeAllStudentsWithApartmentID(getID);
                adminApartments.updateApartmentData(getID, addressAp.Text, priceNumeric.Value.ToString(), propertyTypeComboBox.Text,
                    interiorComboBox.Text, bedroomsComboBox.Text, roomsQuantity.Text);
                apartmentsDataTable = adminApartments.GetApartments();
                MessageBox.Show("Succesfully updated");
            }
            else if (dialogResult == DialogResult.No)
            {

            }
        }
        private void updateApartmentBtn_Click(object sender, EventArgs e)
        {
            int check = 0;
            if (!String.IsNullOrEmpty(addressAp.Text) && priceNumeric.Value != 0 &&
               !String.IsNullOrEmpty(propertyTypeComboBox.Text) && !String.IsNullOrEmpty(interiorComboBox.Text) &&
               !String.IsNullOrEmpty(bedroomsComboBox.Text) && !String.IsNullOrEmpty(roomsQuantity.Text) && int.TryParse(roomsQuantity.Text, out check) == true)
            {
                areYouSure();
                comboBoxApartIds();
                usersDataTable = studentAuthority.GetUsers();
                apartmentsDataTable = adminApartments.GetApartments();
                dataGridView1.DataSource = apartmentsDataTable;
            }
            else
                MessageBox.Show("Please fill all fields", "Error some field are empty");
        }

        private void updateApDataBtn_Click(object sender, EventArgs e)
        {
            if (updateApartmentBtn.Visible == false)
                visibleFalse();
            if (dataGridView1.Rows.Count > 0)
            {
                updateApartmentBtn.Visible = true;
                updateApartmentInfo();
            }
            else
                MessageBox.Show("There is no data");
            createApartmentBtn.Visible = false;
            updateApartmentBtn.Visible = true;
        }
        private void updateApartmentInfo()
        {
            List<String> copy = adminApartments.apartmentDataInfo(Convert.ToInt32(dataGridView1.Rows[getIndex()].Cells[0].Value));
            idTxtBox.Text = copy[0];
            addressAp.Text = copy[1];
            priceNumeric.Value = Decimal.Parse(copy[2]);
            propertyTypeComboBox.Text = copy[3];
            interiorComboBox.Text = copy[4]; ;
            bedroomsComboBox.Text = copy[5];
            roomsQuantity.Text = copy[6];
        }
        #endregion


        private void onClick(object sender, DataGridViewCellEventArgs e)
        {
            if (updateApartmentBtn.Visible == true)
                updateApartmentInfo();
        }
       
        private void ClosingForm(object sender, FormClosingEventArgs e)
        {
            this.Visible = false;
            LoginForm openForm = new LoginForm();
            openForm.Visible = true;
        }
        private int getIndex()
        {
            int rc = dataGridView1.CurrentCell.RowIndex;
            return rc;
        }

        private void changeDataGrid(object sender, EventArgs e)
        {
            if (adminInterface.SelectedIndex == 0)               
                dataGridView1.DataSource = usersDataTable;
            if (adminInterface.SelectedIndex == 1)
                dataGridView1.DataSource = apartmentsDataTable;

        }
    }
}
