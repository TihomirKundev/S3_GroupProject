﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
namespace Project
{
    class UploadScheduleData
    {
        private readonly string dataLink = "Server=mssql.fhict.local;Database=dbi484379;User Id=dbi484379;Password=1234;";

        protected internal DataTable uploadScheduleUsers()
        {
            SqlConnection con = new SqlConnection(@dataLink);
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT Day,Job FROM Schedule WHERE ApartmentID = '" + User.apartmentID + "' AND " +
                "UserID= '" + User.userID+ "'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            con.Close();
            return dt;
        }
        protected internal List<String> scheduleObligations()
        {
            List<String> Days = new List<string>();
            SqlConnection con = new SqlConnection(@"Server=mssql.fhict.local;Database=dbi484379;User Id=dbi484379;Password=1234;");
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT Job,Day FROM Schedule WHERE ApartmentID = '" + User.apartmentID + "' AND " +
                "UserID= '" + User.userID+ "' ", con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                if (dr.GetValue(1).ToString() == "Monday")
                    Days.Add("Mo: " + dr.GetValue(0).ToString());
                if (dr.GetValue(1).ToString() == "Tuesday")
                    Days.Add("Tu: " + dr.GetValue(0).ToString());
                if (dr.GetValue(1).ToString() == "Wednesday")
                    Days.Add("We: " + dr.GetValue(0).ToString());
                if (dr.GetValue(1).ToString() == "Thursday")
                    Days.Add("Th: " + dr.GetValue(0).ToString());
                if (dr.GetValue(1).ToString() == "Friday")
                    Days.Add("Fr: " + dr.GetValue(0).ToString());
                if (dr.GetValue(1).ToString() == "Saturday")
                    Days.Add("Sa: " + dr.GetValue(0).ToString());
                if (dr.GetValue(1).ToString() == "Sunday")
                    Days.Add("Su: " + dr.GetValue(0).ToString());
            }
            con.Close();
            return Days;
        }
    }
}
