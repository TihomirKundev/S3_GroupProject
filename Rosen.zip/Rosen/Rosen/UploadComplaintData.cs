﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
namespace Project
{
    class UploadComplaintData
    {
        private readonly string dataLink = "Server=mssql.fhict.local;Database=dbi484379;User Id=dbi484379;Password=1234;";
        public void sendComplaint(string complaint)
        {
            SqlConnection con = new SqlConnection(@dataLink);
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into ComplaintMessages values (@ApartmentID,@Complaint)", con);
            cmd.Parameters.AddWithValue("@ApartmentID", User.apartmentID);
            cmd.Parameters.AddWithValue("@Complaint", complaint);
            cmd.ExecuteNonQuery();
            con.Close();
        }
    }
}
